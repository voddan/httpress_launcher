#!/usr/bin/python
# coding=utf-8
# httpress_launcher.py
# Lunches external bin 'httpress' (httpress_rh6)
#
import re
import subprocess
import time
import sys
import logging
from argparse import ArgumentParser

from report import HttpressReport
from report import HttpressReportCollector

# ---
class SSHKEY:
    def __init__(self):
        pass

    def __repr__(self):
        return 'SHHKEY'

class Host:
    """
    Contains information about launching one particular instance of httpress bin
    such ass system and connection logging information
    """
    def __init__(self, login, password, hostname):
        """
        :type login: str
        :type password: str | Environment.SHHKEY
        :type hostname: str
        """
        self.login = login
        self.password = password
        self.hostname = hostname

    def __eq__(self, other):
        """
        :type other: Host
        :rtype: bool
        """
        return isinstance(other, Host) and \
               self.login == other.login and \
               self.password == other.password and \
               self.hostname == other.hostname

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return 'Host(%s, %s, %s)' % \
               (self.login, str(self.password), self.hostname)

class LocalHost(Host):
    """
    Special case of launching tests on the local machine
    Does not require login or password
    Should always be treated as a special case
    """
    def __init__(self):
        Host.__init__(self, '', '', 'localhost')
        # in order to support '__eq__(Host(..), LocalHost()) == False'
        self.login = None
        self.password = None

    def __repr__(self):
        return 'LocalHost'

def parse_host_lines(host_lines):
    """
    Parses a list of hostname string representations

    :type host_lines: list[str]
    :rtype: list[Host]
    """

    # not sure about characters which are allowed in passwords
    # used 'http://goo.gl/jtsM9v' (IBM): r'[\w!\)\(-.?\]\[`~]'
    # also consider 'http://goo.gl/9QfGvt': r'[^ \s"\'`&\)\(><|:]'
    password_characters = r'[\w!\)\(-.?\]\[`~]'
    hostname_characters = r'[a-zA-Z0-9_-]'
    # IPv6 is not supported

    expr_user = r'(?P<login>\w+)@'
    expr_pass = r'(?P<password>(%s)+):' % password_characters
    expr_host_ipv4 = r'\d+\.\d+\.\d+\.\d+'
    expr_host_name = r'((%s)+\.)*(%s)+' % (hostname_characters, hostname_characters)
    expr_host = r'(?P<hostname>(%s)|(%s))' % (expr_host_ipv4, expr_host_name)

    expression = r'^(%s)?(%s)?(%s)$' % (expr_user, expr_pass, expr_host)
    pattern = re.compile(expression)

    hosts = []
    for line in host_lines:
        clean_line = line.strip()
        if clean_line == '':
            # we do not need warning messages on empty lines
            continue

        match = pattern.match(clean_line)
        if not match:
            logging.warning("Host line '%s' has incorrect format" % clean_line)
            continue

        login = match.group('login')
        password = match.group('password')
        hostname = match.group('hostname')

        # it fits 'localhost' in any font-case
        if hostname.lower() == 'localhost':
            hosts.append(LocalHost())
            if login or password:
                logging.warning("Attributes are ignored for localhost in '%s'" % clean_line)
        else:
            if not login:
                login = "root"
            if not password:
                password = SSHKEY()

            hosts.append(Host(login, password, hostname))

    return hosts

def load_host_lines_from_single_file(filename):
    """
    :type filename: str
    :rtype: list[str]
    """
    try:
        f = open(filename)
    except IOError:
        logging.error("File %s can't be open for reading" % filename)
        return []

    host_list = []

    try:
        for line in f:
            host_list.append(line)
    except IOError:
        logging.warning("List of hosts from %s may be incomplete" % filename)
    finally:
        f.close()

    return host_list


class HttpressComLine:
    """
    Class to keep data form ComLine which is needed for the main program
    """
    def __init__(self, host_line_list, filename_list, parameters_to_pass):
        """
        :type host_line_list: list[str]
        :type filename_list: list[str]
        :type parameters_to_pass: list[str]
        """
        self.host_line_list = host_line_list
        self.filename_list = filename_list
        self.parameters_to_pass = parameters_to_pass

    def __repr__(self):
        return 'HttpressComLine(%s; %s; %s)' % \
               (self.host_line_list, self.filename_list, self.parameters_to_pass)

def httpress_get_help_msg(bin_path):
    """
    Lunches httpress bin (httpress_bin_path) and returns its help message

    Note: option '-h' must mean 'show help' for 'httpress'

    :rtype: str
    """
    try:
        child = subprocess.Popen([bin_path, '-h'],
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE)

        (child_out, child_err) = child.communicate()

        if child_err != '':
            # should be cached inside the method
            raise RuntimeError
    except:
        logging.error("Help message of %s can't be get. "
                          "Try '%s -h'" %
                          ((bin_path,) * 2))
        return "HELP MESSAGE CAN NOT BE DISPLAYED"

    return child_out

def argparse_parse_args(bin_path, comline_arguments=None, comline_values=None):
    """
    Parses command line arguments, options equivalent to argparse.parse_args(args, values)

    Note:
        option '--help' must be unused by 'httpress'
        option '-h' must mean 'show help' for 'httpress'

    :type bin_path: str
    :type comline_values: dict[str,str]
    :type comline_arguments: list[str]
    :rtype: HttpressComLine
    """
    parser = ArgumentParser(add_help=False)

    # option '--help' must be unused by httpress bin
    parser.add_argument('--help', action='store_true', dest='run_script_help',
                        help="show help messages both for the script and for the 'httpress', then exit", default=False)

    # option '-h' must mean 'show help' for httpress bin
    parser.add_argument('-h', action='store_true', dest='run_httpress_help',
                        help="show 'httpress' help messages", default=False)

    # no warning message on multi hosts
    parser.add_argument("--hosts", dest="hosts_string_list", metavar="HOSTS", action="append", type=str,
                        help="list of HOSTS in format [login@][password:](IPv4|host_name) or 'localhost'", default=[])

    parser.add_argument("-f", "--file", dest="filename_list", metavar="FILE", action="append", type=str,
                        help="read host options from FILE in addition to HOSTS", default=[])

    parser.add_argument("-v", "--verbose", action="store_true", dest="verbose",
                        help="logging level to logging.INFO", default=False)

    # debugging options: undocumented, no unit-tests
    parser.add_argument("--script-debug", action="store_true", dest="script_debug",
                        help="logging level to logging.DEBUG", default=False)

    (arguments, parameters_to_pass) = parser.parse_known_args(comline_arguments[1:], comline_values)

    if not comline_arguments and not comline_values:
        logging.error("Command line is empty. Nothing to do.")
        exit()

    if arguments.run_script_help:
        parser.print_help(sys.stdout)
        print ('=' * 40)
        print (httpress_get_help_msg(bin_path))
        exit()

    if arguments.run_httpress_help:
        print httpress_get_help_msg(bin_path)
        exit()

    host_list = []
    for hosts_string in arguments.hosts_string_list:
        if hosts_string != '':
            host_list.extend(hosts_string.split(','))

    if (arguments.filename_list is not None) and len(arguments.filename_list) > 1:
        logging.info("More than one --file/-f argument is provided. "
                                   "Content is taken from all sources: %s" %
                                   str(arguments.filename_list))

    if arguments.verbose:
        logging.getLogger().setLevel(logging.INFO)
    else:
        logging.getLogger().setLevel(logging.ERROR)

    # Makes sense to have INFO level to debug concurrency and SSH
    if arguments.script_debug:
        logging.getLogger().setLevel(logging.DEBUG)

    return HttpressComLine(host_list,
                           arguments.filename_list,
                           parameters_to_pass)


def collect_output(children_list):
    """
    Collects output from child processes

    :type children_list: list[(POpen|None, Host, float)]
    :rtype: (list[str], list[(Host, float, str)])
    """
    output_list = []
    failed_list = []
    for (child, host, millitime) in children_list:
        if child is None:
            failed_list.append((host, millitime, ""))
            continue

        (out, err) = child.communicate()
        if not err:
            output_list.append(out)
        else:
            failed_list.append((host, millitime, err))

    return output_list, failed_list

def launch_localhost(bin_path, args=()):
    """
    Launches one instance of the bin file on LocalHost

    :type bin_path: str | None
    :type args: list[str]
    :rtype: (POpen|None, float)
    """
    comline_list = [bin_path] + args

    millitime = time.time() * 1000
    logging.info("launching LocalHost at time[millisec]: %f" % millitime)
    try:
        child = subprocess.Popen(comline_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        logging.debug("subprocess.Popen: %f", time.time())
    except:
        logging.error("Unable to launch an instance on LocalHost at %f with '%s'" %
                          (millitime, ' '.join(comline_list)))
        child = None

    return child, millitime

def launch_localhost_life(bin_path, args=()):
    """
    Launches one instance of the bin file on LocalHost
    Prints the result to text_stream instantly right while processing

    :type bin_path: str | None
    :type args: list[str]

    :rtype: (POpen|None, float, str, str)
    """
    (child, milli) = launch_localhost(bin_path, args)

    if not child:
        return None, milli, "", ""

    logging.debug("output_text: %f", time.time())

    output_text = ""
    out_iter = iter(child.stdout.readline, "")
    for line in out_iter:
        output_text += line
        print line,

    (error_text) = child.communicate()[1]
    print >> sys.stdout, error_text,

    return child, milli, output_text, error_text

def launching(hosts, bin_path, args):
    """
    Launches executable 'bin_path' with 'args' on 'hosts'
    and prints the outputs interactively.

    Returns a list of outputs from successful instances

    Does not change 'hosts' itself

    :type hosts: list[Host]
    :type bin_path: str
    :type args: list[str]
    :rtype: list[str]
    """
    logging.info("ready to launch on hosts: %s" % str(hosts))

    # using one LocalHost for a better process control (starts from 0)
    if LocalHost() in hosts:
        hosts.remove(LocalHost())  # ValueError
        launch_special_child = True
    else:
        launch_special_child = False

    # LAUNCHING THE REST (starts from 1)
    # TODO: support remote launching
    children_list = []
    for host in hosts:
        (child, millitime) = launch_localhost(bin_path, args)
        children_list.append((child, host, millitime))

    if launch_special_child:
        print '===========%4d (life) ======' % 0
        logging.debug("launch_special_child: %f", time.time())
        (special_child, special_milliseconds, special_output, special_err) \
             = launch_localhost_life(bin_path, args)

    # WAITING FOR THE REST
    (output_list, failed_list) = collect_output(children_list)

    for i, output in enumerate(output_list):
        print '===========%4d =============' % (i + 1)
        print output

    # APPENDING THE SPECIAL CHILD
    if launch_special_child:
        if special_err or (not special_child) or (special_child.returncode < 0):
            failed_list.append((LocalHost(), special_milliseconds, special_err))
        else:
            output_list.append(special_output)

    print '=== FAILED:         %4d =================' % len(failed_list)
    logging_level_info = (logging.getLogger().level <= logging.INFO)
    for (host, millitime, error) in failed_list:
        print 'Task on %s at %f FAILED' % (str(host), millitime)
        if logging_level_info:
            print error

    # to keep 'hosts' there state
    if launch_special_child:
        hosts.append(LocalHost())

    return output_list


def main(bin_path, comline_argv):
    """

    :type bin_path: str
    :type comline_argv: list[str]
    """
    logging.debug(comline_argv)

    options = argparse_parse_args(bin_path, comline_argv)

    logging.debug('options: %s' % str(options))
    logging.debug('parameters: %s' % str(options.parameters_to_pass))
    # ----------------------------------
    # COMBINING host_lines
    host_lines = options.host_line_list

    for filename in options.filename_list:
        logging.info('loading a hostlist from: %s' % filename)
        host_lines.extend(load_host_lines_from_single_file(filename))

    logging.debug('host_lines: %s' % str(host_lines))
    # --------------------
    hosts = parse_host_lines(host_lines)

    logging.debug('hosts: %s' % str(hosts))
    # ----------------
    # assuming LocalHost if no hosts are provided
    if not hosts:
        hosts.append(LocalHost())

    output_list = launching(hosts, bin_path, options.parameters_to_pass)

    report_list = [HttpressReport().parse(output) for output in output_list]

    collector = HttpressReportCollector()
    for report in report_list:
        collector.collect(report)

    main_report = collector.report()

    print '=== LAUNCHED:       %4d =================' % len(hosts)
    print '=== SUCCESSFULLY:   %4d =================' % len(output_list)
    print '=========================================='

    try:
        print main_report.__str__()
    except HttpressReport.EmptyReportError:
        print 'no report'
    except HttpressReport.StructureError:
        print 'Total report can not be printed. Please consider: %s' % main_report.__repr__()


#========================
# USE the mock version if your connection is slow

if __name__ == '__main__':
    # httpress_bin_path = "bin/httpress_rh6"
    httpress_bin_path = "bin/httpress_mock_slow_error.py"
    main(httpress_bin_path, sys.argv)

# coding=utf-8
#
# report.py
# Methods for transforming the stdout of 'httpress' bin
#
__author__ = 'voddan'
__package__ = None

# <editor-fold desc="HTTPRESS OUTPUT SPEC">
#
# TOTALS:  400 connect, 400 requests, 399 success, 1 fail, 20 (20) real concurrency
# RESPONSE: 2xx 299 (100.0%), non-2xx 0 (0.0%)
# TRAFFIC: 56139 avg bytes, 1034 avg overhead, 11171738 bytes, 412921 overhead
# TIMING:  2.026 seconds, 198 rps, 11110 kbps, 100.5 ms avg req time
# loops: 200; failed: 1; time: 2.026; rate: { 199.029 } req/sec;
#
# </editor-fold>

import re

class HttpressReport:
    """
    Data class for parsing, keeping
    and printing the stdout of 'httpress' bin
    """
    def __init__(self):
        """
        :type self.lines: list[list]
        """
        self.lines = []
        self.number_of_lines = 5

    def __repr__(self):
        return self.lines.__repr__()

    def __str__(self):
        if len(self.lines) == 0:
            raise HttpressReport.EmptyReportError(self)

        if len(self.lines) != self.number_of_lines:
            raise HttpressReport.StructureError(self)

        result = ''
        try:
            result += 'TOTALS:  %d connect, %d requests, %d success, %d fail, %d (%d) real concurrency\n' % tuple(self.lines[0])
            result += 'RESPONSE: 2xx %d (%.1f%%), non-2xx %d (%.1f%%)\n' % tuple(self.lines[1])
            result += 'TRAFFIC: %d avg bytes, %d avg overhead, %d bytes, %d overhead\n' % tuple(self.lines[2])
            result += 'TIMING:  %.3f seconds, %d rps, %d kbps, %.1f ms avg req time\n' % tuple(self.lines[3])
            result += 'loops: %d; failed: %d; time: %.3f; rate: { %.3f } req/sec;' % tuple(self.lines[4])
        except TypeError:
            HttpressReport.StructureError(self)

        return result

    def parse(self, text):
        """
        Parsers text and fulls up the self instance, then returns it

        :type text: str
        :rtype: HttpressReport
        """
        self.lines = []

        expressions = [
            r'TOTALS:  (\d+) connect, (\d+) requests, (\d+) success, (\d+) fail, (\d+) \((\d+)\) real concurrency$',
            r'RESPONSE: 2xx (\d+) \((\d+\.\d+)%\), non-2xx (\d+) \((\d+\.\d+)%\)$',
            r'TRAFFIC: (\d+) avg bytes, (\d+) avg overhead, (\d+) bytes, (\d+) overhead$',
            r'TIMING:  (\d+\.\d+) seconds, (\d+) rps, (\d+) kbps, (\d+\.\d+) ms avg req time$',
            r'loops: (\d+); failed: (\d+); time: (\d+\.\d+); rate: \{ (\d+\.\d+) \} req/sec']

        # on an exception any tests fails
        patterns = [re.compile(expression, re.MULTILINE)
                    for expression in expressions]

        # a performance optimisation
        matches = []
        pos = 0
        for pattern in patterns:
            match = pattern.search(text, pos=pos)

            if match is not None:
                matches.append(match)
                pos = match.end() + 1
            else:
                raise HttpressReport.ParsingError(pattern.pattern, text, pos)

        for match in matches:
            accumulator = []
            for string in match.groups():
                try:
                    try:
                        accumulator.append(int(string))
                    except ValueError:
                        accumulator.append(float(string))
                except ValueError:
                    # nothing else may be get because
                    # the expression collects only digits
                    raise

            self.lines.append(accumulator)

        return self

    class ParsingError(RuntimeError):
        def __init__(self, incorrect_line, text, start_pos):
            RuntimeError.__init__(self, "Unable to match pattern (re) on position %d: %s\n '''%s'''" %
                                        (start_pos, incorrect_line, text))
            self.incorrect_line = incorrect_line
            self.text = text  # may be useful on handling
            self.start_pos = start_pos

    class StructureError(RuntimeError):
        def __init__(self, report):
            self.report = report
            RuntimeError.__init__(self, "Internal structure of the report is invalid: %s" %
                                  str(report.lines))

    class EmptyReportError(StructureError):
        pass


class HttpressReportCollector:
    """
    Class for transforming data in HttpressReport
    Collects data from HttpressReports one by one,
    then may be transformed to a HttpressReport by
    the report() method
    """

    class Functor:
        def __init__(self, name, collect_f, report_f):
            self.__repr__ = lambda: name

            """
            Mixes up 'old' values from HttpressReportCollector
            with 'new' values form HttpressReport

            :type old: int | float
            :type new: int | float
            :rtype:    int | float
            """
            self.collect = collect_f

            """
            Converts values from HttpressReportCollector
            to values for HttpressReport

            :type count: int
            :type value: int | float
            :rtype:      int | float
            """
            self.report = report_f

    sum = Functor('Sum', (lambda a, b: a + b), (lambda c, v: v))
    max = Functor('Max', (lambda a, b: max(a, b)), (lambda c, v: v))
    avr = Functor('Avr', (lambda a, b: a + b), (lambda c, v: (v / c) if c else v))
    nth = Functor('Nth', (lambda a, b: 0), (lambda c, v: -1))

    functors = (
        (sum, sum, sum, sum, sum, sum),
        (sum, nth, sum, nth),
        (avr, avr, sum, sum),  # by SPEC it should be (nth, nth, sum, sum)
        (nth, avr, sum, avr),  # by SPEC it should be (nth, nth, sum, avr)
        (sum, sum, max, sum)
    )
    # fixme: what is the meaning of 'Timing: 2.0026 sec'?

    def __init__(self):
        self.count = 0
        self.lines = []

    def __repr__(self):
        result = 'HttpressReportCollector( count = %d,\n' % self.count
        result += ''.join(['\t%s,\n' % str(line) for line in self.lines])
        result += ')'
        return result

    def report(self):
        """
        Transforms HttpressReportCollector
        to a HttpressReport

        :rtype: HttpressReport
        """
        assert self.lines

        functors = HttpressReportCollector.functors

        new_lines = [
            [functors[index][i].report(self.count, self.lines[index][i])
                for i in range(len(functors[index]))]

            for index in range(len(functors))
        ]

        report = HttpressReport()
        report.lines = new_lines
        return report

    def collect(self, report):
        """
        Collects a HttpressReport

        :type report: HttpressReport
        """
        if self.count == 0:
            self.lines = report.lines
            self.count += 1
        else:
            assert self.lines

            functors = HttpressReportCollector.functors

            new_lines = [
                [functors[index][i].collect(self.lines[index][i], report.lines[index][i])
                    for i in range(len(functors[index]))]

                for index in range(len(functors))
            ]

            self.lines = new_lines
            self.count += 1
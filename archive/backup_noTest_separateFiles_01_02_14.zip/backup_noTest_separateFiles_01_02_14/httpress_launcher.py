#!/usr/bin/python
# coding=utf-8
# httpress_launcher.py
# Lunches external bin 'httpress' (httpress_rh6)
#
__author__ = 'voddan'
__package__ = None

import os
import sys
import logging

__file_path__ = os.path.dirname(os.path.realpath(__file__))
__project_root__ = __file_path__ + '/../'

from common import load_host_lines_from_single_file
from report import HttpressReport
from report import HttpressReportCollector
from comline import argparse_parse_args
from hostline import parse_host_lines
from hostline import LocalHost
from launching import launch_localhost
from launching import launch_localhost_life
from launching import collect_output


def launching(hosts, bin_path, args):
    """
    Launches executable 'bin_path' with 'args' on 'hosts'
    and prints the outputs interactively.

    Returns a list of outputs from successful instances

    Does not change 'hosts' itself

    :type hosts: list[Host]
    :type bin_path: str
    :type args: list[str]
    :rtype: list[str]
    """
    logging.info("ready to launch on hosts: %s" % str(hosts))

    # using one LocalHost for a better process control (starts from 0)
    if LocalHost() in hosts:
        hosts.remove(LocalHost())  # ValueError
        launch_special_child = True
    else:
        launch_special_child = False

    # LAUNCHING THE REST (starts from 1)
    # TODO: support remote launching
    children_list = []
    for host in hosts:
        (child, millitime) = launch_localhost(bin_path, args)
        children_list.append((child, host, millitime))

    if launch_special_child:
        print '===========%4d (life) ======' % 0
        (special_child, special_milliseconds, special_output, special_err) \
             = launch_localhost_life(bin_path, args)

    # WAITING FOR THE REST
    (output_list, failed_list) = collect_output(children_list)

    for i, output in enumerate(output_list):
        print '===========%4d =============' % (i + 1)
        print output

    # APPENDING THE SPECIAL CHILD
    if launch_special_child:
        if special_err or not special_child:
            failed_list.append((LocalHost(), special_milliseconds, special_err))
        else:
            output_list.append(special_output)

    print '=== FAILED:         %4d =================' % len(failed_list)
    logging_level_info = (logging.getLogger().level <= logging.INFO)
    for (host, millitime, error) in failed_list:
        print 'Task on %s at %f FAILED' % (str(host), millitime)
        if logging_level_info:
            print error

    # to keep 'hosts' there state
    if launch_special_child:
        hosts.append(LocalHost())

    return output_list

def main(bin_path, comline_argv):
    """

    :type bin_path: str
    :type comline_argv: list[str]
    """
    logging.debug(comline_argv)

    options = argparse_parse_args(bin_path, comline_argv)

    logging.debug('options: %s' % str(options))
    # ----------------------------------
    # COMBINING host_lines
    host_lines = options.host_line_list

    for filename in options.filename_list:
        logging.info('loading a hostlist from: %s' % filename)
        host_lines.extend(load_host_lines_from_single_file(filename))

    logging.debug('host_lines: %s' % str(host_lines))
    # --------------------
    hosts = parse_host_lines(host_lines)

    logging.debug('hosts: %s' % str(hosts))
    # ----------------
    # assuming LocalHost if no hosts are provided
    if not hosts:
        hosts.append(LocalHost())

    output_list = launching(hosts, bin_path, options.parameters_to_pass)

    report_list = [HttpressReport().parse(output) for output in output_list]

    collector = HttpressReportCollector()
    for report in report_list:
        collector.collect(report)

    main_report = collector.report()

    print '=== LAUNCHED:       %4d =================' % len(hosts)
    print '=== SUCCESSFULLY:   %4d =================' % len(output_list)
    print '=========================================='

    try:
        print main_report.__str__()
    except HttpressReport.EmptyReportError:
        print 'no report'
    except HttpressReport.StructureError:
        print 'Total report can not be printed. Please consider: %s' % main_report.__repr__()


#========================
# USE the mock version if your connection is slow

if __name__ == '__main__':
    # httpress_bin_path = "bin/httpress_rh6"
    httpress_bin_path = "bin/httpress_mock_slow_error.py"
    main(httpress_bin_path, sys.argv)

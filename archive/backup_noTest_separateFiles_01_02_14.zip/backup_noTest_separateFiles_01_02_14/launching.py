#!/usr/bin/python
# coding=utf-8
# launching.py
#
import logging
import sys

__author__ = 'voddan'
__package__ = None

import time
import subprocess
import common

# TODO: separate launching and collection of the information

def collect_output(children_list):
    """
    Collects output from child processes

    :type children_list: list[(POpen|None, Host, float)]
    :rtype: (list[str], list[(Host, float, str)])
    """
    output_list = []
    failed_list = []
    for (child, host, millitime) in children_list:
        if child is None:
            failed_list.append((host, millitime, ""))
            continue

        (out, err) = child.communicate()
        if not err:
            output_list.append(out)
        else:
            failed_list.append((host, millitime, err))

    return output_list, failed_list


def launch_localhost(bin_path, args=()):
    """
    Launches one instance of the bin file on LocalHost

    :type bin_path: str | None
    :type args: list[str]
    :rtype: (POpen|None, float)
    """
    comline_list = [bin_path] + args

    millitime = time.time() * 1000
    logging.info("launching LocalHost at time[millisec]: %f" % millitime)
    try:
        child = subprocess.Popen(comline_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except:
        logging.error("Unable to launch an instance on LocalHost at %f with '%s'" %
                          (millitime, ' '.join(comline_list)))
        child = None

    return child, millitime

def launch_localhost_life(bin_path, args=()):
    """
    Launches one instance of the bin file on LocalHost
    Prints the result to text_stream instantly right while processing

    :type bin_path: str | None
    :type args: list[str]

    :rtype: (POpen|None, float, str, str)
    """
    (child, milli) = launch_localhost(bin_path, args)

    if not child:
        return None, milli, "", ""

    out = child.stdout
    err = child.stderr

    output_text = ""
    while True:
        out_line = out.readline()
        output_text += out_line
        sys.stdout.write(out_line)
        if out_line == '':
            break

    error_text = ''.join(err.readlines())
    print >> sys.stdout, error_text

    return child, milli, output_text, error_text
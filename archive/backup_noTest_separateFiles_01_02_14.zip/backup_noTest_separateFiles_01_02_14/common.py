# coding=utf-8
# common.py
# Contains common classes and functions
#
__author__ = 'voddan'
__package__ = None

# VERSION FORMAT: ns.nr_mm.dd.yyyy
# ns - number of stage,
# nr - number of the last code revision
# mm.dd.yyyy - date of the last code revision
__version__ = '0.2_11.04.2014'

from abc import abstractmethod
import logging
import sys


class Comparable:
    @abstractmethod
    def __eq__(self, other):
        pass

    def __ne__(self, other):
        return not self.__eq__(other)


class SSHKEY(Comparable):
    def __init__(self):
        pass

    def __repr__(self):
        return 'SHHKEY'

    def __eq__(self, other):
        return isinstance(other, SSHKEY)


def load_host_lines_from_single_file(filename):
    """
    :type filename: str
    :rtype: list[str]
    """
    try:
        f = open(filename)
    except IOError:
        logging.error("File %s can't be open for reading" % filename)
        # TODO: should be another (module-level) logger
        return []

    host_list = []

    try:
        for line in f:
            host_list.append(line)
    except IOError:
        logging.warning("List of hosts from %s may be incomplete" % filename)
    finally:
        f.close()

    return host_list
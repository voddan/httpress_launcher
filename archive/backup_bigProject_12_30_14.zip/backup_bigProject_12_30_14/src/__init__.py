#!/usr/bin/python
# coding=utf-8
# __init__.py
#
__author__ = 'voddan'
__package__ = None

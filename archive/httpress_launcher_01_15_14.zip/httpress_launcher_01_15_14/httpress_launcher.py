#!/usr/bin/python
# coding=utf-8
# httpress_launcher.py
# Lunches external bin 'httpress' (httpress_rh6)
#
from collections import OrderedDict
import io
from itertools import izip
import os
import re
import socket
import subprocess
import threading
import time
import sys
import logging
from argparse import ArgumentParser
import StringIO
import paramiko
import platform
import traceback

class BinPath:
    """
    :type _list: [BinPath]
    :type _local: str | None
    """
    _list = []
    _local = None

    def __init__(self, str):
        self.str = str
        self.hash = 239  # todo hashcode with exceptions

    @staticmethod
    def init(binpaths):
        """
        Sets up (local) paths to bin httpress for different systems
        Must be called exactly ones

        :type binpaths: list[str]
        """
        assert not BinPath._list
        for str in binpaths:
            try:
                BinPath._list.append(BinPath(str))
            except:  # todo specify exception type
                logging.error("Path %s is incorrect. Make sure you have rights for reading" % str)

        if not BinPath._list:
            raise Exception('No valid binpaths were provided')

    @staticmethod
    def path(hash):
        """
        Returns path to a local bin by hash
        :type hash: int
        :rtype: str | None
        """
        for path in BinPath._list:
            if hash == path.hash:
                return path.str
        return None

    @staticmethod
    def paths():
        """:rtype: [str]"""
        return (path.str for path in BinPath._list)

    @staticmethod
    def localpath():
        """:rtype: str"""
        if BinPath._local:
            return BinPath._local

        for path in BinPath._list:
            try:  # todo: should I turn the executable bit on ?
                child = subprocess.Popen([path.str, '-h'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                assert child
                (_, err) = child.communicate()
                assert '' == err
            except:
                continue
            BinPath._local = path.str
            return path.str

        raise RuntimeError("No of provided paths may be run on LocalHost")


class SSHKEY:
    def __repr__(self):
        return 'SHHKEY'

class Host:
    TIMEOUT = 5  # timeout for every remote operation

    def __init__(self, login, password, hostname):
        """
        :type login: str
        :type password: str | SHHKEY
        :type hostname: str
        """
        self.login = login
        self.password = password
        self.hostname = hostname

        self.start_time = None

        self.stdout_chanel = None
        self.stderr_chanel = None

        # for Host instances only
        self.client = None

    def __repr__(self):
        return 'Host(%s, %s, %s)' % \
               (self.login, self.password, self.hostname)

    # todo: support SHHKEY connection
    def prepare(self):
        """
         connects to host, loads 'httpress' bin, initialises 'client' in the host
         Note: 'self.client' is left active
         Note: there is no need to close a connection before quiting
         Note: may be slow, but it does not affect the second launch because of the cashing
         :except BadHostKeyException, AuthenticationException, SSHException, socket.error, RuntimeError
         :raises AssertionError
        """
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        assert not isinstance(self.password, SSHKEY)  # todo: support

        # TEST
        client.connect(hostname=self.hostname, username=self.login, password=self.password, timeout=Host.TIMEOUT)
        # client.connect(hostname=self.hostname, username=self.login)
        sftp = client.open_sftp()

        if 1 == int(client.exec_command('test -d /tmp/httpress_launcher/; echo $?', timeout=Host.TIMEOUT)[1].read()):
            sftp.mkdir("/tmp/httpress_launcher/", 0777)

        sftp.chmod("/tmp/httpress_launcher/", 0777)

        for binpath in BinPath.paths():
            # todo: check if exist and compare hashes (search in the list)
            sftp.put(binpath, "/tmp/httpress_launcher/httpress")
            sftp.chmod("/tmp/httpress_launcher/httpress", 0777)

            stderr = client.exec_command('/tmp/httpress_launcher/httpress -h')[2].read()
            if stderr == '':  # testing if the binary works
                sftp.close()
                self.client = client
                return

        # todo: use something more distinguishable
        raise RuntimeError("Non of the given files can run at %s \nLinux distro: %s" %
                           (self, platform.linux_distribution()))

    def launch(self, args):
        """
        Suppose to work as fast as possible
        :type args: list[str]
        :except SSHException
        :raises AssertionError
        """
        assert self.client  # must have been set in 'prepare'
        self.start_time = time.time()

        logging.info("launching %s at time[sec]: %f" % (self, self.start_time))
        (_, self.stdout_chanel, self.stderr_chanel) \
            = self.client.exec_command('/tmp/httpress_launcher/httpress ' + ' '.join(args))

    def output(self):
        """
        :except EnvironmentError
        :raises AssertionError
        """
        assert self.stdout_chanel  # must have been set in 'launch'
        assert self.stderr_chanel  # must have been set in 'launch'
        # raises EnvironmentError
        out = self.stdout_chanel.read()
        err = self.stderr_chanel.read()

        return Output(self, out, err)

    def close(self):
        # todo: consider more checking
        if self.client is not None:
            self.client.close()

class LocalHost(Host):
    """
    Does not require 'login' or 'password'
    """
    def __init__(self):
        Host.__init__(self, None, None, 'localhost')

    def __repr__(self):
        return 'LocalHost'

    def prepare(self):
        assert BinPath.localpath()

    def launch(self, args):
        comline_list = [BinPath.localpath()] + args
        self.start_time = time.time()
        logging.info("launching LocalHost at time[sec]: %f" % self.start_time)
        child = subprocess.Popen(comline_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        assert child
        self.stdout_chanel = child.stdout
        self.stderr_chanel = child.stderr

    def close(self):
        pass

class Output:
    def __init__(self, host, out, err):
        """
        :type host: Host
        :type out: str
        :type err: str
        """
        self.host = host
        self.out = out
        self.err = err

        if host.start_time:
            self.start_time = host.start_time
        else:  # the host never was launched
            self.start_time = 0

    def __repr__(self):
        if self.start_time > 0:
            return 'Output(%s, %s, len(out): %d, len(err): %d)' % \
                (self.host, self.start_time, len(self.out), len(self.err))
        else:
            return 'Output(%s, err: %s) WAS NEVER LAUNCHED' % (self.host, self.err)

def launching(hosts, args):
    """
    Launches executable 'bin_path' with 'args' on 'hosts'
    and prints the outputs interactively.
    Returns output strings from successful launches

    :type hosts: list[Host]
    :type args: list[str]
    :rtype: list[str]
    """
    logging.info("hosts to launch: %s" % hosts)

    failed_list = []  # outputs from all hosts failed for different reasons

    connected_hosts = []
    for host in hosts:
        try:
            host.prepare()
            connected_hosts.append(host)
            print 'Ready to launch %s' % host
        except (paramiko.BadHostKeyException,
                paramiko.AuthenticationException,
                paramiko.SSHException,
                socket.error,
                RuntimeError), e:
            failed_list.append(Output(host, '', 'Cannot prepare %s\n%s\n' % (host, e.message)))
            logging.error('Cannot prepare %s \nERROR:%s\n' % (host, e.message))
            # failed_list.append(Output(host, '', traceback.format_exc()))

    launched_hosts = []
    for host in connected_hosts:
        try:
            host.launch(args)
            launched_hosts.append(host)
        except paramiko.SSHException, e:
            failed_list.append(Output(host, '', 'Cannot launch %s\n%s\n' % (host, e.message)))
            logging.error('Cannot launch %s \nERROR:%s\n' % (host, e.message))

    successful_list = []
    for host in launched_hosts:
        try:
            output = host.output()
            if output.err:
                failed_list.append(output)
            else:
                successful_list.append(output)
        except EnvironmentError, e:
            failed_list.append(Output(host, '', err=e.message))

    for host in hosts:
        # noinspection PyBroadException
        try:
            host.close()
        except:
            logging.error("Error on closing %s" % host)
            logging.error(traceback.format_exc())

    for i, output in enumerate(successful_list):
        print '===========%4d ============= at %s' % ((i + 1), output.host)
        print output.out

    print '=== FAILED:         %4d =================' % len(failed_list)
    for output in failed_list:
        if output.start_time > 0:
            print 'Task on %s at %f FAILED' % (output.host, output.start_time)
        else:
            print 'Task on %s FAILED TO BE RUN' % output.host

        print output.err

    return [output.out for output in successful_list]


def load_host_lines_from_single_file(filename):
    """
    :type filename: str
    :rtype: list[str]
    """
    try:
        _file = open(filename)
    except EnvironmentError, e:
        logging.error("File %s can't be open for reading \nERROR:%s" % (filename, e.message))
        return []

    host_list = []
    try:
        host_list = _file.readlines()
    except EnvironmentError:
        logging.warning("List of hosts from %s may be incomplete" % filename)
    finally:
        _file.close()

    return host_list

def parse_host_lines(host_lines):
    """
    Parses a list of hostname string representations

    :type host_lines: list[str]
    :rtype: list[Host]
    """
    password_characters = r'[\w!\)\(-.?\]\[`~]'
    hostname_characters = r'[a-zA-Z0-9_-]'

    expr_user = r'(?P<login>\w+)@'
    expr_pass = r'(?P<password>(%s)+):' % password_characters
    expr_host_ipv4 = r'\d+\.\d+\.\d+\.\d+'
    expr_host_name = r'((%s)+\.)*(%s)+' % (hostname_characters, hostname_characters)
    expr_host = r'(?P<hostname>(%s)|(%s))' % (expr_host_ipv4, expr_host_name)

    expression = r'^(%s)?(%s)?(%s)$' % (expr_user, expr_pass, expr_host)
    pattern = re.compile(expression)

    hosts = []
    for line in host_lines:
        clean_line = line.strip()
        if clean_line == '':
            continue  # no warning messages on empty lines

        match = pattern.match(clean_line)
        if match is None:
            logging.warning("Host line '%s' has incorrect format" % clean_line)
            continue

        login = match.group('login')
        password = match.group('password')
        hostname = match.group('hostname')

        if hostname.lower() == 'localhost':  # fits 'localhost' in any font-case
            hosts.append(LocalHost())
            if login or password:
                logging.warning("Attributes are ignored for localhost in '%s'" % clean_line)
        else:
            hosts.append(Host(login if login else "root",
                              password if password else SSHKEY(),
                              hostname))

    return hosts

class HttpressComLine:
    """ Class to keep data form ComLine which is needed for the main program """
    def __init__(self, host_line_list, filename_list, parameters_to_pass):
        """
        :type host_line_list: list[str]
        :type filename_list: list[str]
        :type parameters_to_pass: list[str]
        """
        self.host_line_list = host_line_list
        self.filename_list = filename_list
        self.parameters_to_pass = parameters_to_pass

    def __repr__(self):
        return 'HttpressComLine(%s; %s; %s)' % \
               (self.host_line_list, self.filename_list, self.parameters_to_pass)

def httpress_get_help_msg(bin_path):
    """
    Lunches httpress bin (httpress_bin_path) and returns its help message
    Note: option '-h' must mean 'show help' for 'httpress'

    :rtype: str
    """
    # noinspection PyBroadException
    try:
        child = subprocess.Popen([bin_path, '-h'],
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE)

        (child_out, child_err) = child.communicate()
        assert child_err == ''
    except:
        logging.error("Help message of %s can't be get. "
                      "Try '%s -h'" % ((bin_path,) * 2))
        return "HELP MESSAGE CAN NOT BE DISPLAYED"

    return child_out

def argparse_parse_args(comline_arguments=None, comline_values=None):
    """
    Parses command line arguments, options equivalent to argparse.parse_args(args, values)

    Note:
        option '--help' must be unused by 'httpress'
        option '-h' must mean 'show help' for 'httpress'

    :type bin_path: str
    :type comline_values: dict[str,str]
    :type comline_arguments: list[str]
    :rtype: HttpressComLine
    """
    parser = ArgumentParser(add_help=False)

    # option '--help' must be unused by httpress bin
    parser.add_argument('--help', action='store_true', dest='run_script_help',
                        help="show help messages both for the script and for the 'httpress', then exit", default=False)

    # option '-h' must mean 'show help' for httpress bin
    parser.add_argument('-h', action='store_true', dest='run_httpress_help',
                        help="show 'httpress' help messages", default=False)

    parser.add_argument("--hosts", dest="hosts_string_list", metavar="HOSTS", action="append", type=str,
                        help="list of HOSTS in format [login@][password:](IPv4|host_name) or 'localhost'", default=[])

    parser.add_argument("-f", "--file", dest="filename_list", metavar="FILE", action="append", type=str,
                        help="read host options from FILE in addition to HOSTS", default=[])

    parser.add_argument("-v", "--verbose", action="store_true", dest="verbose",
                        help="logging level to logging.INFO", default=False)

    (arguments, parameters_to_pass) = parser.parse_known_args(comline_arguments[1:], comline_values)

    if not comline_arguments[1:] and not comline_values:
        logging.error("Command line is empty. Nothing to do.")
        parser.print_help(sys.stdout)
        exit()

    if arguments.run_script_help:
        parser.print_help(sys.stdout)
        print ('=' * 40)
        print (httpress_get_help_msg(BinPath.localpath()))
        exit()

    if arguments.run_httpress_help:
        print httpress_get_help_msg(BinPath.localpath())
        exit()

    host_list = []
    for hosts_string in arguments.hosts_string_list:
        if hosts_string != '':
            host_list.extend(hosts_string.split(','))

    if (arguments.filename_list is not None) and len(arguments.filename_list) > 1:
        logging.info("More than one --file/-f argument is provided. "
                                   "Content is taken from all sources: %s" %
                                   arguments.filename_list)

    if arguments.verbose:
        logging.getLogger().setLevel(logging.INFO)
    else:
        logging.getLogger().setLevel(logging.ERROR)

    return HttpressComLine(host_list,
                           arguments.filename_list,
                           parameters_to_pass)


class HttpressReport:
    """ Data class for parsing, keeping and printing the stdout of 'httpress' """
    NUMBER_OF_VALUES = 22

    def __init__(self):
        self.values = []

    def __str__(self):
        if len(self.values) == 0:
            raise HttpressReport.EmptyReportError(self)

        assert len(self.values) == HttpressReport.NUMBER_OF_VALUES
        try:
            result =\
                ('TOTALS:  %d connect, %d requests, %d success, %d fail, %d (%d) real concurrency\n'
                 'RESPONSE: 2xx %d (%.1f%%), non-2xx %d (%.1f%%)\n'
                 'TRAFFIC: %d avg bytes, %d avg overhead, %d bytes, %d overhead\n'
                 'TIMING:  %.3f seconds, %d rps, %d kbps, %.1f ms avg req time\n'
                 'loops: %d; failed: %d; time: %.3f; rate: { %.3f } req/sec;' % tuple(self.values))
        except TypeError:
            raise RuntimeError("Internal structure of the report is invalid:", self)

        return result

    def parse(self, text):
        """
        Parsers text and fulls up the self instance, then returns it

        :type text: str
        :rtype: HttpressReport
        """
        self.values = []

        expression = \
            (r'^TOTALS:  (\d+) connect, (\d+) requests, (\d+) success, (\d+) fail, (\d+) \((\d+)\) real concurrency$\s'
             r'^RESPONSE: 2xx (\d+) \((\d+\.\d+)%\), non-2xx (\d+) \((\d+\.\d+)%\)$\s'
             r'^TRAFFIC: (\d+) avg bytes, (\d+) avg overhead, (\d+) bytes, (\d+) overhead$\s'
             r'^TIMING:  (\d+\.\d+) seconds, (\d+) rps, (\d+) kbps, (\d+\.\d+) ms avg req time$\s'
             r'^loops: (\d+); failed: (\d+); time: (\d+\.\d+); rate: \{ (\d+\.\d+) \} req/sec')

        pattern = re.compile(expression, re.MULTILINE)
        match = pattern.search(text)
        if match is None:
            logging.error("The output does not match the expectations")
            raise RuntimeError("Unable to parse the text:", text)

        for string in match.groups():
            try:
                try:
                    self.values.append(int(string))
                except ValueError:
                    self.values.append(float(string))
            except ValueError:
                raise  # nothing else may be get because the expression collects only digits (with dots)

        return self

    class EmptyReportError(RuntimeError):
        pass

class HttpressReportCollector:
    """
    Class for transforming data in HttpressReport
    Collects data from HttpressReports one by one,
    then may be transformed to a HttpressReport by
    the report() method
    """

    class Functor:
        def __init__(self, name, collect_f, report_f):
            self.__repr__ = lambda: name
            self.collect = collect_f  # updated_value   = collect(old_value, new_value)
            self.report = report_f    # value_to_report = report(count: int, value)

    sum = Functor('Sum', (lambda a, b: a + b), (lambda c, v: v))
    max = Functor('Max', (lambda a, b: max(a, b)), (lambda c, v: v))
    avr = Functor('Avr', (lambda a, b: a + b), (lambda c, v: (v / c) if c else v))
    nth = Functor('Nth', (lambda a, b: 0), (lambda c, v: -1))

    functors = (
        sum, sum, sum, sum, sum, sum,
        sum, nth, sum, nth,
        avr, avr, sum, sum,  # by SPEC it should be: nth, nth, sum, sum,
        nth, avr, sum, avr,  # by SPEC it should be: nth, nth, sum, avr,
        sum, sum, max, sum
    )
    # fixme: what is the meaning of 'Timing: 2.0026 sec'?

    def __init__(self):
        assert len(HttpressReportCollector.functors) == HttpressReport.NUMBER_OF_VALUES
        self.count = 0
        self.values = []

    def report(self):
        """
        Transforms HttpressReportCollector to a HttpressReport

        :rtype: HttpressReport
        """
        report = HttpressReport()

        if len(self.values) == 0:
            return report  # empty report for no data

        assert len(self.values) == HttpressReport.NUMBER_OF_VALUES
        functors = HttpressReportCollector.functors

        new_values = [functor.report(self.count, value)
                      for functor, value in izip(functors, self.values)]

        report.values = new_values
        return report

    def collect(self, report):
        """
        Collects one HttpressReport

        :type report: HttpressReport
        """
        functors = HttpressReportCollector.functors

        if self.count:
            new_values = [functor.collect(self_value, value)
                            for functor, self_value, value
                            in izip(functors, self.values, report.values)]
        else:
            new_values = report.values

        self.values = new_values
        self.count += 1


def main(comline_argv):
    options = argparse_parse_args(comline_argv)

    host_lines = options.host_line_list

    for filename in options.filename_list:
        logging.info('loading a hostlist from: %s' % filename)
        host_lines.extend(load_host_lines_from_single_file(filename))

    hosts = parse_host_lines(host_lines)

    # assuming LocalHost if no hosts are provided
    # if not hosts:
    #     hosts.append(LocalHost())

    output_list = launching(hosts, options.parameters_to_pass)

    try:
        report_list = [HttpressReport().parse(output) for output in output_list]
    except RuntimeError:
        logging.error("Unable to parse the output")
        return exit(1)

    collector = HttpressReportCollector()
    for report in report_list:
        collector.collect(report)

    main_report = collector.report()

    print '=== LAUNCHED:       %4d =================' % len(hosts)
    print '=== SUCCESSFULLY:   %4d =================' % len(output_list)
    print '=========================================='

    # noinspection PyBroadException
    try:
        print main_report.__str__()
    except HttpressReport.EmptyReportError:
        print 'no report'
    except:
        logging.error('Total report can not be printed')


#========================
if __name__ == '__main__':
    BinPath.init(["httpress_rh6", "httpress_fc20", "httpress_mock_slow_error.py"])
    main(sys.argv)
